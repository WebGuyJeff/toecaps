<?php
/**
 * Toecaps Template - CSS-Loader.
 *
 * Enqueue any theme-conditional scripts and styles here. This template is called from header.php.
 *
 * @package   Toecaps
 * @author    Jefferson Real <me@jeffersonreal.uk>
 * @copyright Copyright (c) 2022, Jefferson Real
 */

return;

/*
if ( is_front_page() || is_home() ) {

	return;

} else {

	if ( is_page() && $post->post_parent ) {

		// This is a child page.
		wp_enqueue_style( 'parent_css' );

	} else {

		// This is a parent page.
		wp_enqueue_style( 'parent_css' );

	}
}
*/
