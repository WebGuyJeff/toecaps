<?php


/**
 * Toecaps Template Part - Dev Landing Page - Cost Section.
 *
 * @package   Toecaps
 * @author    Jefferson Real <me@jeffersonreal.uk>
 * @copyright Copyright (c) 2022, Jefferson Real
 */
?>

<div class="landing_content " style="--row: 1 / -1; --col: narrow-l / narrow-r;">

	<div class="copy">
		<h2>Example Section Title</h2>
		<p>This is an Example Template Section Part.</p>
	</div>

</div>

<div class="landing_backdrop"></div>
